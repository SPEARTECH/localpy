
from localpy import localpy

def main():
    localpy.main()

if __name__ == "__main__":
    main()
